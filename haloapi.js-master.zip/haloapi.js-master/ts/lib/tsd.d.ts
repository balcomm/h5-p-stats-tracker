/// <reference path="request-promise/request-promise.d.ts" />
