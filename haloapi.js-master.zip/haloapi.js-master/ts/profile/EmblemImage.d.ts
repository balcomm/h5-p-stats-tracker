
/**
 * The URL of an image of the player's emblem
 */
declare type EmblemImage = url; 