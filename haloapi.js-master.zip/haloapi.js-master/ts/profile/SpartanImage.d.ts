
/**
 * The URL of the player's Spartan Image
 */
declare type SpartanImage = url; 